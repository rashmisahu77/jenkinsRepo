import logo from "./logo.svg";
import "./App.css";
import User from "./User";

function App() {
  return (
    <div className="App">
      <div>
        <User />
      </div>
      {/* <header className="App-header">
       
      </header> */}
    </div>
  );
}

export default App;
